// RealSubject
/*
 * quello che vogliamo che faccia il subject
 */
class MathImpl implements Math {
	public double add(float a, float b) {
		return a + b;
	}
	
	public double sub(float a, float b) {
		return a - b;
	}
	
	public double mul(float a, float b) {
		return a * b;
	}
	
	public double div(float a, float b) {
		return a / b;
	}
	
}