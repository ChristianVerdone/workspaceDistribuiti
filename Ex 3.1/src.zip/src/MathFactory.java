//sostituto dell'operatore new
public interface MathFactory {
	public Math create();
}
